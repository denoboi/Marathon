﻿
namespace HCB.Core
{
    public static class SavedFileNameHolder
    {
        public static string PlayerData = "PlayerData";
    }
}
