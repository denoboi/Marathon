﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using HCB.Utilities;

namespace HCB.Core
{
    public class Managers : Singleton<Managers>
    {

    }
}
