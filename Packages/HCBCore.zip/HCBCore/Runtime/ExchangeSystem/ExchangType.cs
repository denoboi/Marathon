﻿
namespace HCB
{
    public enum ExchangeType
    {
        Invalid = 0,
        Coin = 1,
    }
}
